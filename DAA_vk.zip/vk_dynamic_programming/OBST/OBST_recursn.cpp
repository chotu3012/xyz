//OBST Recursion
//vinay
#include<bits/stdc++.h>
using namespace std;


int sum(vector<int>freq,int i,int j)
{    int sum=0;
	for(int k=i;k<=j;k++)
	{
		sum+=freq[k];
	}
	return sum;
}

int OBST(vector<int>freq,int i,int j)
{
	int val,mi=INT_MAX;
	if(i==j)
		return freq[i];

	if(i>j)
		return 0;
	
	else
	{  
		for(int k=i;k<=j;k++)
		{
            val=OBST(freq,i,k-1)+OBST(freq,k+1,j)+sum(freq,i,j);

            if(val<mi)
            	mi=val;
		}
		return mi;
	}
}
int main()
{
	int n;
	cin>>n;
	vector<int>freq(n);

	for(int i=0;i<n;i++)
	{
		cin>>freq[i];
	}

	cout<<OBST(freq,0,n-1);

}