#include<bits/stdc++.h>
using namespace std;

//Min number of coins recursion
//vinay
int min_coins(vector<int>&coins,int W,int n)
{
	int mi=INT_MAX;
  if(W==0)
    return 0;
  if(n==0)
    return mi;
 
 if(coins[n-1]<=W)
    return min(1+min_coins(coins,W-coins[n-1],n),min_coins(coins,W,n-1));
  else
    return min_coins(coins,W,n-1);
}

int main()
{
  int n;
  cin>>n;
  vector<int>coins(n);

  for(auto i=0;i<n;i++)
  	cin>>coins[i];

  int W;
  cin>>W;

  cout<<"Min number of coins = "<<min_coins(coins,W,n);
}