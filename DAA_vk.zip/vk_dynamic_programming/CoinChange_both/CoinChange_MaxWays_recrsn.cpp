#include<bits/stdc++.h>
using namespace std;

//Maximum number of ways (Coin Change) recursion
//vinay

int coinchange(vector<int>&coins,int W,int n)
{
  
    if(n==0)
     return 0;

   else if(W==0)
      return 1;
   
   
   else if(coins[n-1]<=W)
   	return coinchange(coins,W-coins[n-1],n)+coinchange(coins,W,n-1);

   else
   	return coinchange(coins,W,n-1);
}


int main()
{
	int n;
	cin>>n;

	vector<int>coins(n);

	for(auto i=0;i<n;i++)
		cin>>coins[i];

	int W;
	cin>>W;

	cout<<"max ways = "<<coinchange(coins,W,n);
}

