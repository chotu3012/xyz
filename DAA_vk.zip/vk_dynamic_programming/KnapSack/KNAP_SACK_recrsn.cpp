#include<bits/stdc++.h>
using namespace std;


int knap_sack(int wt[],int val[],int W,int n)
{

	if(n==0 || W==0)
		return 0;
	if(wt[n-1]<=W)
	{
		return max(val[n-1]+knap_sack(wt,val,W-wt[n-1],n-1),knap_sack(wt,val,W,n-1));
  }
    else
	return knap_sack(wt,val,W,n-1);


}

int main()
{
	int n;
	cin>>n;
	int val[n],wt[n];
	int W;
	
	for(int i=0;i<n;i++)
	   cin>>wt[i];
	for(int i=0;i<n;i++)
	   cin>>val[i];
	cin>>W;
	cout<<knap_sack(wt,val,W,n);
}