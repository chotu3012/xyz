//matrix chain multiplication recursion
//vinay
#include<bits/stdc++.h>
using namespace std;

int MCM(int a[],int i,int j)
{
	int val;
	
	if(i==j)
	return 0;
	
	
		int min=INT_MAX;
		for(int k=i;k<j;k++)
		    {
		    	val=MCM(a,i,k)+MCM(a,k+1,j)+(a[i-1]*a[k]*a[j]);
		    	
		    if(min>val)
		       min=val;
		  	}
			return min;
}



int main()
{     
 	int n;
 	//cout<<"Enter the number of matrices";
	cin>>n;
	int a[n+1];
//	cout<<"Enter the sizes of matrices in an array"<<endl<<endl;
	for(int i=0;i<n+1;i++)
 	{
  	cin>>a[i];
     }
  	cout<<MCM(a,1,n);
}