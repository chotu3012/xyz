//Permutations of a given array without repetation (backtracking)
//vinay
#include<bits/stdc++.h>
using namespace std;

int c=0;
void print(int *a,int *b,int n)
{
	for(int i=0;i<n;i++)
		cout<<a[b[i]]<<" ";  //in b array there are indexes;
	  cout<<endl;
}

bool is_safe(int *b,int index,int i)
{
	for(int j=0;j<index;j++)
	{
		if(b[j]==i)
			return 0;
	}
	return 1;
}
void permutations(int *a,int *b ,int index,int n)
{
	 if(index==n)
	 {
	 	c++; 
	 	print(a,b,n);
	 	return;
	 }

	 for(int i=0;i<n;i++)
	 {
	 	if(is_safe(b,index,i))
	 	{
	 	 b[index]=i;
	 	 permutations(a,b,index+1,n);
	 	}
	 }
}
int main(){
	int n;
	cin>>n;

	int a[n];

	for(auto i=0;i<n;i++)
		cin>>a[i];
   
   int b[n];
	permutations(a,b,0,n);
    cout<<endl<<"Number of permutations = "<<c;
}