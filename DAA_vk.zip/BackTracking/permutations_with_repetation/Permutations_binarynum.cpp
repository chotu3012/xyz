//Permutations of binarry numbers (backtracking)
//vinay
#include<bits/stdc++.h>
using namespace std;

int c=0;
void print(int *a,int n)
{
	for(int i=0;i<n;i++)
		cout<<a[i]<<" ";
	  cout<<endl;
}
void permutations(int *a,int index,int n)
{
	 if(index==n)
	 {
	 	c++; 
	 	print(a,n);
	 	return;
	 }

	 for(int i=0;i<=1;i++)
	 {
	 	 a[index]=i;
	 	 permutations(a,index+1,n);
	 }
}
int main(){
	int n;
	cin>>n;

	int a[n];

	
	permutations(a,0,n);
	cout<<"Number of permutations = "<<c;
    
}