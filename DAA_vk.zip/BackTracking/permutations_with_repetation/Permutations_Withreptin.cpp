//Permutations of given array with repitation (backtracking)
//vinay
#include<bits/stdc++.h>
using namespace std;

int c=0;
void print(int *a,int *b,int n)
{
	for(int i=0;i<n;i++)
		cout<<a[b[i]]<<" ";
	  cout<<endl;
}

void permutations(int *a,int *b ,int index,int n)
{
	 if(index==n)
	 {
	 	c++; 
	 	print(a,b,n);
	 	return;
	 }

	 for(int i=0;i<n;i++)
	 {
	 	 b[index]=i;
	 	 permutations(a,b,index+1,n);
	 }
}
int main(){
	int n;
	cin>>n;

	int a[n];

	for(auto i=0;i<n;i++)
		cin>>a[i];
   
   int b[n];
	permutations(a,b,0,n);
	cout<<endl<<"Number of permutations = "<<c;
    
}