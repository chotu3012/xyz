//Permutations of a given alphabets with repetation (backtracking)
//vinay
#include<bits/stdc++.h>
using namespace std;

int c=0;
void print(char *a,int *b,int n)
{
	for(int i=0;i<n;i++)
		cout<<a[b[i]]<<" ";
	  cout<<endl;
}


void permutations(char *a,int  *b ,int index,int n)
{
	 if(index==n)
	 {
	 	c++; 
	 	print(a,b,n);
	 	return;
	 }

	 for(int i=0;i<n;i++)
	 {
	 	 b[index]=i;
	 	 permutations(a,b,index+1,n);
	 	
	 }
}
int main(){
	
	int n;
	cin>>n;

    char a[n];
    for(int i=0;i<n;i++)
       cin>>a[i];             
      
      int b[n]; //to store indexes;

	permutations(a,b,0,n);
    cout<<"Number of permutations = "<<c;
}